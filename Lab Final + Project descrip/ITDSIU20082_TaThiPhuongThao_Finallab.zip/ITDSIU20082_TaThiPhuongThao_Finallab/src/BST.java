import java.util.ArrayList;
import java.util.List;

public class BST {
    class Node {
        int data;
        Node left, right;

        public Node(int item) {
            data = item;
            left = right = null;
        }
    }

    private Node root;

    // Constructor
    public BST() {
        root = null;
    }

    // 1. Insert a node
    public void insert(int data) {
        root = insertNode(root, data);
    }

    private Node insertNode(Node root, int data) {
        if (root == null) {
            root = new Node(data);
            return root;
        }
        if (data < root.data) {
            root.left = insertNode(root.left, data);
        } else if (data > root.data) {
            root.right = insertNode(root.right, data);
        }
        return root;
    }

    // 2. Delete a node by value
    public void delete(int data) {
        root = deleteNode(root, data);
    }

    private Node deleteNode(Node root, int data) {
        if (root == null) {
            return root;
        }

        if (data < root.data) {
            root.left = deleteNode(root.left, data);
        } else if (data > root.data) {
            root.right = deleteNode(root.right, data);
        } else {
            // Node with only one child or no child
            if (root.left == null)
                return root.right;
            else if (root.right == null)
                return root.left;

            // Get the in-order successor (smallest in the right subtree)
            root.data = minValue(root.right);

            // Delete the in-order successor
            root.right = deleteNode(root.right, root.data);
        }

        return root;
    }

    private int minValue(Node root) {
        int minValue = root.data;
        while (root.left != null) {
            root = root.left;
            minValue = root.data;
        }
        return minValue;
    }

    // 3. Search for a node by value
    public void search(int data) {
        boolean found = searchNode(root, data);
        printSearch(data, found);
    }

    private boolean searchNode(Node root, int data) {
        if (root == null) {
            return false;
        }
        if (data < root.data) {
            return searchNode(root.left, data);
        } else if (data > root.data) {
            return searchNode(root.right, data);
        } else {
            return true; 
        }
    }

    // 4. In-order traversal
    public void inOrderTraversal() {
        List<Integer> result = new ArrayList<>();
        inOrderRec(root, result);
        printInOrder(result);
    }

    private void inOrderRec(Node root, List<Integer> result) {
        if (root != null) {
            inOrderRec(root.left, result);
            result.add(root.data);
            inOrderRec(root.right, result);
        }
    }

    private void printSearch(int data, boolean found) {
        if (found) {
            System.out.println("find " + data + " in the tree.");
        } else {
            System.out.println("cant find " + data + " in the tree.");
        }
    }

    private void printInOrder(List<Integer> result) {
        System.out.println("In-order traversal: " + result);
    }

    public static void main(String[] args) {
        BST tree = new BST();
        tree.insert(50);
        tree.insert(30);
        tree.insert(20);
        tree.insert(40);
        tree.insert(70);
        tree.insert(60);
        tree.insert(80);

        tree.delete(20);
        tree.delete(30);
        tree.delete(50);

        tree.search(70);  // should print "Found 70 in the tree."
        tree.search(90);  // should print "Could not find 90 in the tree."

        tree.inOrderTraversal();  // should print "In-order traversal: [40, 60, 70, 80]"
    }
}