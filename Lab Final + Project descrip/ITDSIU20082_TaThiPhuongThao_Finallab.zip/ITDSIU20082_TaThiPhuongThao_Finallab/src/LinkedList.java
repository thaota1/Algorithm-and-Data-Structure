class LinkedList {
    class Node {
        int data;
        Node next;
        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }
    
    private Node head;

    // Constructor
    public LinkedList() {
        this.head = null;
    }

    // 1. Insert a node at the end
    public void insertAtEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
        printInsertAtEnd(data);
    }

    // 2. Insert a node at the beginning
    public void insertAtBeginning(int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
        printInsertAtBeginning(data);
    }

    // 3. Delete a node by value
    public void deleteByValue(int data) {
        if (head == null) return;
        if (head.data == data) {
            head = head.next;
            printDeleteByValue(data, true);
            return;
        }
        Node temp = head;
        while (temp.next != null) {
            if (temp.next.data == data) {
                temp.next = temp.next.next;
                printDeleteByValue(data, true);
                return;
            }
            temp = temp.next;
        }
        printDeleteByValue(data, false);
    }

    // 4. Search for a node by value
    public void search(int data) {
        Node temp = head;
        boolean found = false;
        while (temp != null) {
            if (temp.data == data) {
                found = true;
                break;
            }
            temp = temp.next;
        }
        printSearch(data, found);
    }

    // Helper method to print the list (optional)
    public void printList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    //print insert at end
    private void printInsertAtEnd(int data) {
        System.out.println("insert " + data + " at the end of the list");
    }

    //print insert at beginning
    private void printInsertAtBeginning(int data) {
        System.out.println("insert " + data + " at the beginning of the list");
    }

    //print delete by value
    private void printDeleteByValue(int data, boolean deleted) {
        if (deleted) {
            System.out.println("deleted " + data );
        } else {
            System.out.println("cant find " + data );
        }
    }

    //print search
    private void printSearch(int data, boolean found) {
        if (found) {
            System.out.println("find " + data  );
        } else {
            System.out.println("cant find " + data );
        }
    }

    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.insertAtEnd(5);
        list.insertAtEnd(10);
        list.insertAtBeginning(1);
        list.deleteByValue(5);
        list.search(10);  // should return true
        list.search(5);  // should return false

        list.printList();  // Optional: Print the list to check the final state
    }
}